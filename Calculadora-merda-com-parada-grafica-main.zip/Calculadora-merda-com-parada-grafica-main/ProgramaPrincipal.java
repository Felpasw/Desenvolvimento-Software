package logica;
import grafica.*;

public class ProgramaPrincipal {
    public static void main(String[] args) {
        FrmCalculadora frm = new FrmCalculadora();
        frm.setVisible(true);
    }       
}
