package grafica;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class FrmCalculadora extends JFrame {
    private JTextField txtDisplay;
    public FrmCalculadora(){
        // define layout do JFrame
        // Divide em 5 regioes: norte, sul, leste, oeste e centro.
        setLayout(new BorderLayout());
        // painel norte
        JPanel pnlnorte = new JPanel(new BorderLayout());
        txtDisplay = new JTextField();
        this.add(pnlnorte, BorderLayout.NORTH);
        this.txtDisplay = new JTextField();
        pnlnorte.add(this.txtDisplay, BorderLayout.CENTER);
        // painel centro
        JPanel pnlcentro = new JPanel(new GridLayout(5, 4, 5, 5));
        this.add(pnlcentro);
        //botões
        JButton btn = new JButton("C");
        pnlcentro.add(btn);

        btn = new JButton("*");
        pnlcentro.add(btn);

        btn = new JButton("X²");
        pnlcentro.add(btn);

        btn = new JButton("<");
        btn.addActionListener(new ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent e) {
                String txtAntigo = txtDisplay.getText();
                if(txtAntigo.length() > 0){
                    txtDisplay.setText(txtAntigo.substring(0, txtAntigo.length() - 1));
                }
                
            }
        });
        pnlcentro.add(btn);

        btn = new JButton("7");
        btn.addActionListener(new ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent e) {
                String txtAntigo = txtDisplay.getText();
                txtDisplay.setText(txtAntigo.concat("7"));
            }
        });
        
        pnlcentro.add(btn);

        btn = new JButton("8");
        btn.addActionListener(new ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent e) {
                String txtAntigo = txtDisplay.getText();
                txtDisplay.setText(txtAntigo.concat("8"));
            }
        });
        pnlcentro.add(btn);

        btn = new JButton("9");
        btn.addActionListener(new ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent e) {
                String txtAntigo = txtDisplay.getText();
                txtDisplay.setText(txtAntigo.concat("9"));
            }
        });
        pnlcentro.add(btn);
        
        btn = new JButton("/");
        pnlcentro.add(btn);
        
        btn = new JButton("4");
        btn.addActionListener(new ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent e) {
                String txtAntigo = txtDisplay.getText();
                txtDisplay.setText(txtAntigo.concat("4"));
            }
        });
        pnlcentro.add(btn);
        
        btn = new JButton("5");
        btn.addActionListener(new ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent e) {
                String txtAntigo = txtDisplay.getText();
                txtDisplay.setText(txtAntigo.concat("5"));
            }
        });
        pnlcentro.add(btn);
        
        btn = new JButton("6");
        btn.addActionListener(new ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent e) {
                String txtAntigo = txtDisplay.getText();
                txtDisplay.setText(txtAntigo.concat("6"));
            }
        });
        pnlcentro.add(btn);

        btn = new JButton("+");
        pnlcentro.add(btn);

        btn = new JButton("1");
        btn.addActionListener(new ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent e) {
                String txtAntigo = txtDisplay.getText();
                txtDisplay.setText(txtAntigo.concat("1"));
            }
        });
        pnlcentro.add(btn);

        btn = new JButton("2");
        btn.addActionListener(new ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent e) {
                String txtAntigo = txtDisplay.getText();
                txtDisplay.setText(txtAntigo.concat("2"));
            }
        });
        pnlcentro.add(btn);
        
        btn = new JButton("3");
        btn.addActionListener(new ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent e) {
                String txtAntigo = txtDisplay.getText();
                txtDisplay.setText(txtAntigo.concat("3"));
            }
        });
        pnlcentro.add(btn);

        btn = new JButton("-");
        pnlcentro.add(btn);
        
        btn = new JButton("+/-");
        pnlcentro.add(btn);

        btn = new JButton("0");
        btn.addActionListener(new ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent e) {
                String txtAntigo = txtDisplay.getText();
                txtDisplay.setText(txtAntigo.concat("0"));
            }
        });
        pnlcentro.add(btn);

        btn = new JButton(".");
        pnlcentro.add(btn);

        btn = new JButton("=");
        pnlcentro.add(btn);

        this.pack();
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}